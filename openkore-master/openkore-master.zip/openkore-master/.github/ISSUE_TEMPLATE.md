
## ------------------ Openkore Issues Template ------------------
<!-- all message is hidden -->

<!-- Before submitting an issue, ensure you are on the latest release -->
<!-- Check if an issue already exists for your request -->
<!-- Please post in English if possible -->
<!-- -DON'T DELETE THIS. FILL THIS FORM. -->
<!-- -Use this template or your issue will be closed. -->

* **Openkore version git**: 
<!-- find Version git :[GitHub hash](https://github.com/OpenKore/openkore/wiki/How-to-check-version-git-you-bot.)-->
* **Server**: 
<!-- ex. iRO/kRO/bRO/cRO -->
* **Bug Report / Feature Request**:
<!-- Your problem is Bug Report / Feature Request . ex = **Bug Report / Feature Request**: Feature Request -->
* **Summary**:
<!-- Summarize your problem ex. New map is coming EP. 99 -->
