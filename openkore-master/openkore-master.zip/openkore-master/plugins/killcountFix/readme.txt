Some servers won't send the killing mission goals until a certain action is made (like killing a mob).
This plugin fixes that by saving a list of all killing quest goals.
For this plugin work as expected the user must copy the file 'quests_killcount.txt' to the tables folder.
New | custom | modified quests will be updated automatically into the file when the server sends info about them.