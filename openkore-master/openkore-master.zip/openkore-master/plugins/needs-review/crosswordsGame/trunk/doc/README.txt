AUTHOR: KeplerBR
TOPIC:
 [EN] http://forums.openkore.com/viewtopic.php?f=34&t=49616
 [PT-BR] http://forums.openkore-brasil.com/index.php?/topic/384-plugin-4fun-ca%C3%A7a-palavras/