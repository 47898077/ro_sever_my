#ifndef _TIGER_H_
#define _TIGER_H_

#include "../typedefs.h"

void tiger(const dword *str, dword length, dword *res);

#endif